export const PICK_AUCTION = 'PICK_AUCTION';
export const PICK_PARAM = 'PICK_PARAM';
export const PICK_COST = 'PICK_COST';