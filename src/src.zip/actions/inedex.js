import * as actionTypes from '../constants';

export const doAddAuction = payload => ({
  type: actionTypes.PICK_AUCTION,
  payload,
});

export const doAddParam = payload => ({
  type: actionTypes.PICK_PARAM,
  payload,
});

export const doAddCost = payload => ({
  type: actionTypes.PICK_COST,
  payload,
});

export default { doAddAuction, doAddParam, doAddCost };
