import React from 'react';
import Typography from '@material-ui/core/Typography';
import Select from '../components/select';
import Radio from '../components/radio';
import Paper from '../components/paper';

import auction_data, { copartState } from '../data/auction';
import { useFormInput } from '../components/functions';

function Step1 (){
  const auction = useFormInput('');
  const usaState = useFormInput('');
  const playground = useFormInput('');

  window.localStorage.setItem('auction', auction.value);
  window.localStorage.setItem('usaState', usaState.value);
  window.localStorage.setItem('playground', playground.value);

  return (
    <form autoComplete='off' style={{ maxWidth: 350 }}>
      <Paper>
        <div>
          <Typography variant='display1'>Aукцион</Typography>
        </div>
        <Radio
          labelPlacement='Выберите аукцион'
          {...auction}
          options={auction_data}
        />
        <Select
          header='Выберите штат'
          {...usaState}
          options={copartState}
        />{' '}
        <br />
        <Select
          header='Выберите площадку аукциона'
          {...playground}
          options={copartState}
        />
      </Paper>
    </form>
  );
}

export default Step1;
