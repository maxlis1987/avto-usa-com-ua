import * as actionTypes from '../constants';

const initialState = {
  auction: null,
  usaState: null,
  playground: null,
  fuel: null,
  engine: null,
  year: null,
  cost: null,
  brocker: null,
  comision: null,
  sertificate: null,
  expenses: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.PICK_AUCTION: {
      return addApplyPickAuction(state, action);
    }
    case actionTypes.PICK_PARAM: {
      return addApplyPickParam(state, action);
    }
    case actionTypes.PICK_COST: {
      return addApplyPickCost(state, action);
    }
    default:
      return state;
  }
};

const addApplyPickAuction = (state, action) => ({
  ...state,
  ...action.payload,
});

const addApplyPickParam = (state, action) => ({
  ...state,
  ...action.payload,
});

const addApplyPickCost = (state, action) => ({
  ...state,
  ...action.payload,
});
