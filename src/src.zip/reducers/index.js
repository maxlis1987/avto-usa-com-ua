import { combineReducers } from 'redux';
import stepReducer from './step';

export default combineReducers({
  stepState: stepReducer,
});
