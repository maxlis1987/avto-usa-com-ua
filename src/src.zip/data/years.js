
let year = 1980;
const years = [];

for(let i = 0; i < 42; i++){
 years.push({value: year + i});
}

export default years;