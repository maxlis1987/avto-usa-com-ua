export default [
  {value: "Бензин"},
  {value: "Дизель"},
  {value: "Електро"}
];